#include "stm32f4xx.h"
#include "I2C_Software.h"
#include "delay.h"

void I2C_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStruct.GPIO_Pin = SDA | SCL;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;

    GPIO_Init(GPIO_Port, &GPIO_InitStruct);

    I2C_Stop();
}

void I2C_Start(void)
{
    SDA_1();
    SCL_1();
    SDA_0();
    Delay_us(100);
    SCL_0();
    Delay_us(100);
}

void I2C_Stop(void)
{
    SCL_0();
    Delay_us(100);
    SDA_0();
    Delay_us(100);
    SCL_1();
    Delay_us(100);
    SDA_1();
    Delay_us(100);
}

void I2C_SendByte(uint8_t data)
{
    for(uint8_t i = 0; i < 8; i++)
    {
        SCL_0();

        if(data & 0x80) {SDA_1();}
        else {SDA_0();}
    
        data <<= 1;
        Delay_us(100);
        SCL_1();
        Delay_us(100);
    }
    SCL_0();
    SDA_1();
    Delay_us(100);
    SCL_1();
    Delay_us(1000);
    SCL_0();
}

void I2C_Sendreg(uint8_t Addr, uint8_t data)
{
    I2C_Start();
    Delay_us(200);
    I2C_SendByte(0xC0);
    Delay_us(200);
    I2C_SendByte(Addr);
    Delay_us(200);
    I2C_SendByte(data);
    Delay_us(200);
    I2C_Stop();
}






























































































































































