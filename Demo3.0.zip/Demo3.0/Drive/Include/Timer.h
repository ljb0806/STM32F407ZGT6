#ifndef __TIMER_H
#define __TIMER_H

void TIM2_Init(uint32_t sampling_frequency);
void TIM4_Init(uint16_t arr, uint16_t psc);
void TIM5_Init(uint16_t arr, uint16_t psc);

#endif

