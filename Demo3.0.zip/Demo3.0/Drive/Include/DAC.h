#ifndef __DAC_H
#define __DAC_H

#define DAC1_Value_Length 50
#define DAC2_Value_Length 50

void DAC1_Init(void);
void DAC2_Init(void);

#endif
